import torch
import torch.nn as nn
import torchvision
import torch.nn.functional as F
import torch.optim as optim
import random
from torchvision import datasets, transforms


class AugFashionMNIST(torch.utils.data.Dataset):
    def __init__(self, data, num_transforms):
        self.data = data
        self.data_len = len(self.data)
        self.len = num_transforms * self.data_len

        self.transforms = [
                torchvision.transforms.ColorJitter(brightness=1, contrast=0, saturation=0, hue=0),
                torchvision.transforms.RandomAffine(180, translate=(0.35,0.35), scale=(0.3, 0.3), shear=(-60,60,-60,60)),
                torchvision.transforms.RandomSolarize(128, p=1.0),
                torchvision.transforms.RandomHorizontalFlip(p=1.0),
                torchvision.transforms.RandomVerticalFlip(p=1.0),
                torchvision.transforms.GaussianBlur(kernel_size=5, sigma=(2,6)),
                torchvision.transforms.RandomInvert(p=1.0),
                torchvision.transforms.RandomAdjustSharpness(8,p=1.0),
                torchvision.transforms.RandomAutocontrast(p=1.0),
                torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.4))
                ]
        
    def __getitem__(self, index):
        data_idx = index % self.data_len        
        x, y = self.data[data_idx]
        transformIdx = index // self.data_len
        
        #print(type(x[0]))
        if transformIdx == 0:
            x = x
        elif transformIdx <= 10:
            x = self.transforms[transformIdx - 1](x)
        else:
            x = self.transforms[random.randint(0,9)](x)
            x = self.transforms[random.randint(0,9)](x)
            x = self.transforms[random.randint(0,9)](x)


        return x, y
    
    def __len__(self):
        return self.len


class FCNet(nn.Module):
    def __init__(self):
        super(FCNet, self).__init__()
        self.fc = nn.Linear(in_features=28 * 28,
                            out_features=10)

    def forward(self, x):
        x = torch.flatten(x, start_dim=1)
        x = self.fc(x)
        output = F.log_softmax(x, dim=1)
        return output


class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        self.conv = nn.Conv2d(in_channels=1,
                              out_channels=10,
                              kernel_size=3,
                              stride=2,
                              padding=1)
        self.fc = nn.Linear(in_features=28 * 28 * 10 // (2 * 2),
                            out_features=10)

    def forward(self, x):
        x = self.conv(x)
        x = F.relu(x)
        x = torch.flatten(x, start_dim=1)
        x = self.fc(x)
        output = F.log_softmax(x, dim=1)
        return output


class MyNet(nn.Module):
    """
    Experiment with all possible settings mentioned in the CW page
    """
    def __init__(self):
        super(MyNet, self).__init__()

        self.LINEAR_SIZE_FIRST = 2048
        self.LINEAR_DECAY_FACTOR = 2

        self.L1 = self.ConvBNBlock(1, 256, 3, 1, 1)
        self.MP1 = nn.MaxPool2d(2)
        
        self.L2 = self.ConvBNBlock(256, 256, 3, 1, 1)
        self.L3 = self.ConvBNBlock(256, 512, 3, 1, 1)
        self.L4 = self.ConvBNBlock(512, 256, 3, 1, 1)

        self.L5 = self.ConvBNBlock(256 + 256, 128, 3, 1, 1)  # skip from L2 to L5
        self.MP2 = nn.MaxPool2d(2)

        self.L6 = self.ConvBNBlock(128, 64, 3, 1, 1)
        self.L7 = self.ConvBNBlock(64, 256, 3, 1, 1)
        self.L8 = self.ConvBNBlock(256, 128, 3, 1, 1)

        self.L9 = self.ConvBNBlock(128 + 64, 256, 3, 1, 1)  # skip from L6 to L9
        self.MP3 = nn.MaxPool2d(2)
    
        self.Linear = nn.Sequential(
                        nn.Linear(in_features=3*3*256, out_features=self.LINEAR_SIZE_FIRST),
                        nn.Dropout(0.05),
                        nn.LeakyReLU(0.01),
                        nn.Linear(in_features=self.LINEAR_SIZE_FIRST, out_features= self.LINEAR_SIZE_FIRST // self.LINEAR_DECAY_FACTOR),
                        nn.Dropout(0.05),
                        nn.LeakyReLU(0.01),
                        nn.Linear(in_features=self.LINEAR_SIZE_FIRST // self.LINEAR_DECAY_FACTOR, out_features= self.LINEAR_SIZE_FIRST // (self.LINEAR_DECAY_FACTOR ** 2)),
                        nn.Dropout(0.05),
                        nn.LeakyReLU(0.01),
                        nn.Linear(in_features=self.LINEAR_SIZE_FIRST // (self.LINEAR_DECAY_FACTOR ** 2), out_features= self.LINEAR_SIZE_FIRST // (self.LINEAR_DECAY_FACTOR ** 3)),
                        nn.Dropout(0.05),
                        nn.LeakyReLU(0.01),
                        nn.Linear(in_features=self.LINEAR_SIZE_FIRST // (self.LINEAR_DECAY_FACTOR ** 3), out_features= self.LINEAR_SIZE_FIRST // (self.LINEAR_DECAY_FACTOR ** 4)),
                        nn.Dropout(0.05),
                        nn.LeakyReLU(0.01),
                        nn.Linear(in_features=self.LINEAR_SIZE_FIRST // (self.LINEAR_DECAY_FACTOR ** 4), out_features=10),
                        nn.LogSoftmax()
                        )

        self.weight_init()

    def forward(self, x):
        x = (x - torch.mean(x)) / torch.std(x)
        
        #x = torchvision.transforms.Normalize(x.mean((1)), x.std((1)))(x)
       
        x = self.L1(x)
        x = self.MP1(x)
        x = self.L2(x)
        skip2 = x
        x = self.L3(x)
        x = self.L4(x)

        x = torch.cat((x, skip2), dim=1)
        x = self.L5(x)
        x = self.MP2(x)
              
        x = self.L6(x)
        skip6 = x
        x = self.L7(x)
        x = self.L8(x)
        x = torch.cat((x, skip6), dim=1)
        x = self.L9(x)
        x = self.MP3(x)

        x = torch.flatten(x, start_dim=1)
        output = self.Linear(x)
        return output

    def weight_init(self):
        for lay in self.modules():
            if type(lay) in [torch.nn.Conv2d, torch.nn.Linear]:
                torch.nn.init.xavier_uniform_(lay.weight)

    def ConvBNBlock(self, in_channels, out_channels, kernel_size, stride, padding):
        return nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding),
            nn.Dropout2d(0.025),
            nn.BatchNorm2d(num_features=out_channels),
            nn.LeakyReLU(0.01)
        )


def classify(model, x):
    """
    :param model:    network model object
    :param x:        (batch_sz, 1, 28, 28) tensor - batch of images to classify

    :return labels:  (batch_sz, ) torch tensor with class labels
    """
    #raise NotImplementedError("You have to implement this function.")
    out = model(x)
    labels = torch.argmax(out, dim=1)

    return labels


def get_model_class(_):
    """ Do not change, needed for AE """
    return [MyNet]


def train():
    batch_sz = 2048

    learning_rate = 0.001
    epochs = 20000000

    dataset = datasets.FashionMNIST('data', train=True, download=True,
                                    transform=transforms.ToTensor())


    trn_size = int(0.95 * len(dataset))
    #val_size = int(0.05 * len(dataset))
    val_size = len(dataset) - trn_size
    
    trn_dataset, val_dataset= torch.utils.data.random_split(dataset, [trn_size,
                                                                     val_size])

    
    numTransforms = 15
    trn_dataset = AugFashionMNIST(trn_dataset, numTransforms)
    
    trn_loader = torch.utils.data.DataLoader(trn_dataset,
                                             batch_size=batch_sz,
                                             shuffle=True,
                                             num_workers=6,
                                             pin_memory=True)

    val_loader = torch.utils.data.DataLoader(val_dataset,
                                             batch_size=batch_sz,
                                             shuffle=False,
                                             num_workers=6,
                                             pin_memory=True)

    #device = torch.device("cpu")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    #model = FCNet().to(device)
    model = MyNet().to(device)
    model = nn.DataParallel(model)
    #lossFn = torch.nn.CrossEntropyLoss()
    lossFn = torch.nn.NLLLoss(reduction='mean')
    
    model.module.load_state_dict(torch.load("./model.pt"))
    
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, amsgrad=True, weight_decay=0.0)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.5, patience=5)

    for epoch in range(1, epochs + 1):
        # training
        model.train()
        for i_batch, (x, y) in enumerate(trn_loader):
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            net_output = model(x)
            #net_output = torch.exp(net_output)
            #loss = F.nll_loss(net_output, y)
            loss = lossFn(net_output, y)
            loss.backward()
            optimizer.step()

            if i_batch % 100 == 0:
                print('[TRN] Train epoch: {}, batch: {}\tLoss: {:.4f}'.format(
                    epoch, i_batch, loss.item()))
        

        # validation
        model.eval()
        correct = 0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                net_output = model(x)

                prediction = classify(model, x)
                correct += prediction.eq(y).sum().item()
        val_accuracy = correct / len(val_loader.dataset) 
        scheduler.step(val_accuracy)

        print('[VAL] Validation accuracy: {:.2f}%'.format(100 * val_accuracy))

        torch.save(model.module.state_dict(), "model{:.2f}.pt".format(100 * val_accuracy))


if __name__ == '__main__':
    train()
